﻿#region Using
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
#endregion

namespace RSS_poller
{
    class Program
    {
        static private string url;


        static void Main(string[] args)
        {
            Console.Write("Enter URL: ");
            url = Console.ReadLine();

            TimerCallback callback = new TimerCallback(Poll);
            Timer pollTimer = new Timer(callback, null, 0, 15000);

            string tempExit = Console.ReadLine();
            while (tempExit != "exit" && tempExit != "Exit")
            {
                tempExit = Console.ReadLine();
            }

       // Console.ReadKey();
        }

        public static void Poll(Object stateInfo)
        {
            rssPoller poller = new rssPoller();
            rssFeedData channel = poller.poll(url);

            Console.Clear();

            channel.fullDisplay();

            Console.WriteLine("enter 'Exit' to quit");
        }

    }
}
