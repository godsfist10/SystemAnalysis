#region Using

using System;
using System.Xml;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.ServiceModel.Syndication;
using System.Linq;
using System.Net;
using System.IO;

#endregion
namespace RSS_poller
{
    public class rssPoller
    {
        public string _url { get; set; }
        public Stream resultStream;
        WebRequest mRequest;
        HttpWebResponse mResponse;

        public rssPoller(string url)
        {
            _url = url;
        }

        public rssPoller(){}

        public rssFeedData poll(string url)
        {
            rssPoller poller = new rssPoller();
            rssFeedData channel = new rssFeedData();

            Action<object> action = (object obj) =>
            {
                rssParser parser = new rssParser();

                string response = poller.getReponse(url);
                channel = parser.parseRSS(response);

            };

            Task t1 = Task.Factory.StartNew(action, "alpha");
            try
            {
                t1.Wait();
            }
            catch (System.Exception ex)
            {
                channel = new rssFeedData();
                channel.Title = ex.Message;
                return channel;
            }

            return channel;
        } 

        public string getReponse(string url)
        {
            try
            {
                mRequest = WebRequest.Create(url);
                mResponse = (HttpWebResponse)mRequest.GetResponse();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
           

            // Get the stream containing content returned by the server.
            Stream dataStream;
            try
            {
                dataStream = mResponse.GetResponseStream();
            }
            catch (ProtocolViolationException ex)
            {
                throw new Exception(ex.Message);
            }

            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);

            // Read the content. 
            string responseFromServer = reader.ReadToEnd();

            // Cleanup the streams and the response.
            reader.Close();
            dataStream.Close();
            mResponse.Close();

            return responseFromServer;
        }

    }

}