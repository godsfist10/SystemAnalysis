﻿using System;
using System.Text.RegularExpressions;
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ZipCodeValidator

            public bool validateZipCode(string zipCode)
            {
                return Regex.IsMatch(zipCode, pattern);
            }
            
        }
    }
}
