﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class UnitedStatesZipCodeValidator : ZipCodeValidator
    {
        public override void init()
        {
            pattern = @"^\d{5}(?:[-\s]\d{4})?$";
        }

    }
}
