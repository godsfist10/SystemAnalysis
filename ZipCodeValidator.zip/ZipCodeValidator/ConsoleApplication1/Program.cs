﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            FileIO FileReader = new FileIO();
            List<string> zipCodesList;
            ZipCodeValidator zipCodeValidator;

            string countryName = System.Globalization.RegionInfo.CurrentRegion.EnglishName;

            if (args.Count() == 1)
            {
                zipCodesList = FileReader.loadZipCodeFile(args[0]);
                Console.WriteLine("Reading Zip codes from:  " + args[0] + "\n\n");
            }
            else
            {
                zipCodesList = FileReader.loadZipCodeFile("zipCodes.txt");
            }

            if (zipCodesList != null)
            {
                if (countryName == "United States")
                {
                    zipCodeValidator = new UnitedStatesZipCodeValidator();
                    zipCodeValidator.init();
                    zipCodeValidator.validateListOfZipCodes(zipCodesList);
                }
                else if (countryName == "Canada")
                {
                    zipCodeValidator = new CanadaZipCodeValidator();
                    zipCodeValidator.init();
                    zipCodeValidator.validateListOfZipCodes(zipCodesList);
                }
                else if (countryName == "United Kingdom")
                {
                    zipCodeValidator = new UnitedKingdomZipCodeValidator();
                    zipCodeValidator.init();
                    zipCodeValidator.validateListOfZipCodes(zipCodesList);
                }
            }
            Console.WriteLine("\n\nPress any key to quit...");
            Console.ReadKey();
        }
    }
}
