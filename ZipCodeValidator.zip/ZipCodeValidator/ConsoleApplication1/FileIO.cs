﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication1
{
    public class FileIO
    {
        public List<string> loadZipCodeFile(string filename)
        {
            StreamReader file;
            List<string> tempList = new List<string>();
            string line;
            try
            {
                file = new StreamReader(filename);
            }
            catch (Exception)
            {
                Console.WriteLine("No Such File - Drag your text file into the .exe");
                return null;
            }
            
            while ((line = file.ReadLine()) != null)
            {
               tempList.Add(line);
            }
            file.Close();

            return tempList;
        }

    }
}
