﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public abstract class ZipCodeValidator
    {
        public string pattern = null;

        public abstract void init();

        public virtual bool validateZipCode(string zipCode)
        {
            return Regex.IsMatch(zipCode, pattern);
        }

        public virtual void validateListOfZipCodes(List<string> zipCodeList)
        {
            Console.WriteLine("Invalid Zip Codes Below:");
            foreach (string zipCode in zipCodeList)
            {
                if(!validateZipCode(zipCode))
                    Console.WriteLine(zipCode);
            }

        }
    }
}
