#region Using

using System;
using System.Xml;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.ServiceModel.Syndication;
using System.Linq;
using System.Net;
using System.IO;

#endregion
namespace RSS_poller_Console
{
    public class rssPoller
    {
        public string _url { get; set; }
        public Stream resultStream;

        public rssPoller(string url)
        {
            _url = url;
        }

        public rssPoller(){}

        public rssFeedData poll(string url)
        {
            rssPoller poller = new rssPoller();
            rssFeedData channel = new rssFeedData();

            Action<object> action = (object obj) =>
            {
                rssParser parser = new rssParser();

                string response = poller.getReponse(url);
                channel = parser.parseRSS(response);

            };

            Task t1 = Task.Factory.StartNew(action, "alpha");
            try
            {
                t1.Wait();
            }
            catch (System.Exception ex)
            {
                channel = new rssFeedData();
                channel.Title = "Invalid Feed";
                return channel;
            }

            return channel;
        }

        public string getReponse(string url)
        {
            WebRequest request = WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            // Get the stream containing content returned by the server.
            Stream dataStream;
            try
            {
                dataStream = response.GetResponseStream();
            }
            catch (ProtocolViolationException e)
            {
                throw new Exception("Invalid feed");
            }

            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);

            // Read the content. 
            string responseFromServer = reader.ReadToEnd();

            // Cleanup the streams and the response.
            reader.Close();
            dataStream.Close();
            response.Close();

            return responseFromServer;
        }

    }

}