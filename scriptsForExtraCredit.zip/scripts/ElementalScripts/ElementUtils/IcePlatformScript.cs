﻿using UnityEngine;
using System.Collections;

public class IcePlatformScript : IceDelayedMelt {
	
	public void Start()
	{
		string tempName = "icePlatform_" + PlayerPrefs.GetInt("icePlatforms");

		if( GameObject.Find( tempName) != null)
			Destroy(this.gameObject);

		gameObject.name = tempName;
	}
}
