﻿using UnityEngine;
using System.Collections;

public class NatureBullet : BulletMoveScript {


	void OnTriggerEnter(Collider collider)
	{
		if( collider.tag == "movingWall")
		{

			MoveWall targetScript = collider.GetComponent<MoveWall>();
			targetScript.frozen = true;
			Destroy(gameObject);
		}
	}
}
