﻿using UnityEngine;
using System.Collections;

public class IceBullet : LobbedBullet {

	public GameObject icePlatform = null;

	public int maxIcePlatforms = 10;
	
	void OnTriggerEnter(Collider collider)
	{
		if( collider.tag == "movingWall")
		{
			MoveWall targetScript = collider.GetComponent<MoveWall>();
			targetScript.inhibitSpeed = true;
			Destroy(this.gameObject);
		}
		else if( collider.tag == "Lava")
		{
			Destroy(this.gameObject);
		}
		else
		{
			GameObject icePlatformToDestroy = GameObject.Find("icePlatform_" + (PlayerPrefs.GetInt("icePlatforms") - maxIcePlatforms));
			if( icePlatformToDestroy != null)
				Destroy(icePlatformToDestroy);

			Instantiate( icePlatform, transform.position, Quaternion.identity);
			PlayerPrefs.SetInt("icePlatforms", PlayerPrefs.GetInt("icePlatforms") + 1);
			Destroy(this.gameObject);
		}
	}
}
