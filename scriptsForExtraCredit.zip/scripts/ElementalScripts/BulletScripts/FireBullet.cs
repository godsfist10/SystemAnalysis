﻿using UnityEngine;
using System.Collections;

public class FireBullet : BulletMoveScript {

	void OnTriggerEnter(Collider collider)
	{
		if (collider.tag == "movingWall") 
		{
			MoveWall targetScript = collider.GetComponent<MoveWall> ();
			targetScript.frozen = false;
			targetScript.inhibitSpeed = false;
			Destroy (this.gameObject);
		} 
		else if (collider.tag == "vineWall") 
		{
			Destroy (collider.gameObject);
			Destroy (this.gameObject);
		} 
		else if (collider.tag == "Ice" || collider.tag == "IcePlatform") 
		{
			IceMeltScript targetIceScript = collider.GetComponent<IceMeltScript> ();
			targetIceScript.melting = true;
			Destroy(this.gameObject);
		}
	}
}
