﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ManaBar : MonoBehaviour {

	public Texture fireBarTexture = null;
	public Texture iceBarTexture = null;
	public Texture natureBarTexture = null;
	public Texture electricBarTexture = null;

	public List<float> elementFillList;

	public float maxFill = 0;
	public float minFill = 0;

	public float manaRegenSpeed = 0;
	private int currentManaType = 0; //fire, nature, ice, electric

	private bool mIsGrounded = false;
	private Texture mBarTexture = null;

	// Use this for initialization
	void Start () 
	{
		elementFillList = new List<float>();
		for( int i = 0; i < 4; i++)
			elementFillList.Add(maxFill);

		mBarTexture = fireBarTexture;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(elementFillList[currentManaType] > maxFill)
		{
			elementFillList[currentManaType] = maxFill;
		}

		if( mIsGrounded && elementFillList[currentManaType] < maxFill)
			elementFillList[currentManaType] += manaRegenSpeed;

	}

	public bool canIFire( float energyUse)
	{
		if( elementFillList[currentManaType] - energyUse < 0)
		{
			return false;
		}
		else
		{
			elementFillList[currentManaType] -= energyUse;
			return true;
		}
	}

	public void switchElements( string elementName)
	{
		switch (elementName)
		{
		case "Fire":
			mBarTexture = fireBarTexture;
			currentManaType = 0;
			break;
		
		case "Nature":
			mBarTexture = natureBarTexture;
			currentManaType = 1;
			break;

		case "Ice":
			mBarTexture = iceBarTexture;
			currentManaType = 2;
			break;

		case "Electric":
			mBarTexture = electricBarTexture;
			currentManaType = 3;
			break;
		}
	}

	public void refundMana( float manaRefund)
	{
		elementFillList[currentManaType] += manaRefund;
	}

	public void isGrounded(bool grounded)
	{
		mIsGrounded = grounded;
	}
	
	void OnGUI()
	{
		GUI.DrawTexture(new Rect(((float)Screen.width * .15f), 10, ((float)Screen.width * .70f) * (elementFillList[currentManaType] / maxFill), 15), mBarTexture);
	}
}
