﻿using UnityEngine;
using System.Collections;

public abstract class BaseElementClass : MonoBehaviour {


	// Update is called once per frame
    public virtual void elementUpdate () 
	{
			fireBackAction(checkFireBack());
			fireForwardAction(checkFireForward());
			fireLeftAction(checkFireLeft());
			fireRightAction(checkFireRight());
			y_JumpAction(checkYButton_Jump());
	}
	
	public virtual void fireForwardAction(bool pressed)
	{
		if( pressed)
		Debug.Log("No Action Implemented Yet For Right Trigger");
	}

	public virtual void fireBackAction(bool pressed)
	{
		if( pressed)
		Debug.Log("No Action Implemented Yet For Right Analog Stick");
	}
	
	public virtual void fireLeftAction(bool pressed)
	{
		if( pressed)
		Debug.Log("No Action Implemented Yet For Left Bumper");
	}
	
	public virtual void fireRightAction(bool pressed)
	{
		if( pressed)
		Debug.Log("No Action Implemented Yet For Right Bumper");
	}
	
	public virtual void y_JumpAction(bool pressed)
	{
		if( pressed)
		Debug.Log("No Action Implemented Yet For Y Button");
	}

	public virtual bool checkFireForward()
	{
		bool newTriggerHeld = Input.GetAxis("ForwardFire") > 0f;
		
		if(Input.GetButton("ForwardFire"))
			newTriggerHeld = true;

		if (newTriggerHeld) 
		{	
			return true;
		}

		return false;
	}

	public virtual bool checkFireBack()
	{
		if (Input.GetButtonDown("BackFire"))
		{
			return true;
		}
		return false;
	}

	public virtual bool checkFireLeft()
	{
		if(Input.GetButtonDown("FireLeft"))
		{
			return true;
		}
		return false;
	}

	public virtual bool checkFireRight()
	{
		if(Input.GetButtonDown("FireRight"))
		{
			return true;
		}
		return false;
	}

	public virtual bool checkYButton_Jump()
	{
		if(Input.GetButton("Y_Jump"))
		{
			return true;
		}
		return false;
	}

}
