﻿using UnityEngine;
using System.Collections;

public class FireScript : BaseElementClass {

	public ManaBar manaBarScript = null;
	public GameObject bulletPrefab = null;
	public GameObject bulletSpawnObject = null;
	public ParticleSystem jetPackFire = null;
	public ParticleSystem jetPackFire1 = null;
	public ParticleSystem backPackFire = null;
	public ParticleSystem backPackFire1 = null;
	public ParticleSystem leftFire = null;
	public ParticleSystem rightFire = null;
	
	public float bulletShootCost = 0;
	public float backBoostSpeed = 0;
	public float backBoostCost = 0;
	public float jumpBoostSpeed = 0;
	public float jumpBoostCost = 0;
	public float sideBoostSpeed = 0;
	public float sideBoostCost = 0;

	private bool buttonDown = false;

	public override void fireForwardAction(bool pressed)
	{
		if( pressed)
		{
			if( !buttonDown && manaBarScript.canIFire(bulletShootCost))
			{
				Instantiate(bulletPrefab, bulletSpawnObject.transform.position, bulletSpawnObject.transform.rotation);
				buttonDown = true;
			}
		}
		else
		{
			buttonDown = false;
		}
	}

	public override void fireBackAction(bool pressed)
	{
		if (pressed)
		{
			if(manaBarScript.canIFire(backBoostCost))
			{
				gameObject.rigidbody.AddRelativeForce (Vector3.forward * backBoostSpeed);
				backPackFire.particleSystem.enableEmission = true;
				backPackFire1.particleSystem.enableEmission = true;
			}
		}
		else
		{
			backPackFire.particleSystem.enableEmission = false;
			backPackFire1.particleSystem.enableEmission = false;
		}
	}

	public override void fireLeftAction(bool pressed)
	{
		if(pressed)
		{
			if(manaBarScript.canIFire(sideBoostCost))
			{
				gameObject.rigidbody.AddRelativeForce(-sideBoostSpeed, 0, 0);
				leftFire.particleSystem.enableEmission = true;
			}
		}
		else
		{
			leftFire.particleSystem.enableEmission = false;
		}
	}

	public override void fireRightAction(bool pressed)
	{
		if(pressed)
		{
			if(manaBarScript.canIFire(sideBoostCost))
			{
				gameObject.rigidbody.AddRelativeForce(sideBoostSpeed, 0, 0);
				rightFire.particleSystem.enableEmission = true;
			}
		}
		else
		{
			rightFire.particleSystem.enableEmission = false;
		}
	}

	public override void y_JumpAction(bool pressed)
	{
		if( pressed)
		{
			if(manaBarScript.canIFire(jumpBoostCost))
			{
				gameObject.rigidbody.AddForce(Vector3.up * jumpBoostSpeed);
				jetPackFire.particleSystem.enableEmission = true;
				jetPackFire1.particleSystem.enableEmission = true;
			}
			else
			{
				jetPackFire.particleSystem.enableEmission = false;
				jetPackFire1.particleSystem.enableEmission = false;
			}
		}
		else
		{
			jetPackFire.particleSystem.enableEmission = false;
			jetPackFire1.particleSystem.enableEmission = false;
		}
	}


}
