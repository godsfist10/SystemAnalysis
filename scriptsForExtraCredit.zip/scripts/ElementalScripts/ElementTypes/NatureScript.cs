﻿using UnityEngine;
using System.Collections;

public class NatureScript : BaseElementClass {

	public ManaBar manaBarScript = null;
	public GameObject bulletPrefab = null;
	public GameObject bulletSpawnObject = null;
	public float bulletShootCost = 0;

	private bool buttonDown = false;

	public override void fireForwardAction(bool pressed)
	{
		if( pressed)
		{
			if(!buttonDown && manaBarScript.canIFire(bulletShootCost))
			{
				Instantiate(bulletPrefab, bulletSpawnObject.transform.position, bulletSpawnObject.transform.rotation);
				buttonDown = true;
			}
		}
		else
		{
			buttonDown = false;
		}
	}

}
