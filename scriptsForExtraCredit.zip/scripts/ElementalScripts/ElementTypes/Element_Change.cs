﻿using UnityEngine;
using System.Collections;

public class Element_Change : MonoBehaviour {

	public Material playerSkin = null;
	public ElementalController controller = null;
	public ManaBar manaBarScript = null;

	// Use this for initialization
	void Start () 
	{
		playerSkin.color = Color.red;
	}
	
	// Update is called once per frame
	void Update () 
	{
		SwitchElement ();
	}

	void SwitchElement()
	{
		float VertChange = Input.GetAxis ("VDpad");
		float HoriChange = Input.GetAxis ("HDpad");

		if (VertChange == 1 || Input.GetAxis("VDpadKeyboard") == 1) 
		{
			playerSkin.color = Color.red;
			manaBarScript.switchElements("Fire");
			controller.changeElement("Fire");
			//Debug.Log ("transform Fire");
		}
		if (VertChange == -1 || Input.GetAxis("VDpadKeyboard") == -1) 
		{
			playerSkin.color = Color.blue;
			manaBarScript.switchElements("Ice");
			controller.changeElement("Ice");
			//Debug.Log ("transform Ice");
		}
		if (HoriChange == 1 || Input.GetAxis("HDpadKeyboard") == 1) 
		{
			playerSkin.color = Color.green;
			manaBarScript.switchElements("Nature");
			controller.changeElement("Nature");
			//Debug.Log ("transform Leaves");
		}
		if (HoriChange == -1 || Input.GetAxis("HDpadKeyboard") == -1) 
		{
			playerSkin.color = Color.gray;
			manaBarScript.switchElements("Electric");
			controller.changeElement("Electric");
			//Debug.Log ("transform Lightning");
		}
	}
}
