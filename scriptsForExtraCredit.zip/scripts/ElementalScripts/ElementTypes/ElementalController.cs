﻿using UnityEngine;
using System.Collections;

public class ElementalController : MonoBehaviour {


	public FireScript fireScript = null;
	public NatureScript natureScript = null;
	public ElectricScript electricScript = null;
	public IceScript iceScript = null;
	public BaseElementClass currentElement;

	// Use this for initialization
	void Start () 
	{
		currentElement = fireScript;
		PlayerPrefs.SetInt("icePlatforms", 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
		currentElement.elementUpdate();
	}

	public void changeElement( string elementToChangeTo)
	{
		switch (elementToChangeTo)
		{
		case "Fire":
			currentElement = fireScript;
			break;
			
		case "Nature":
			currentElement = natureScript;
			break;
			
		case "Ice":
			currentElement = iceScript;
			break;
			
		case "Electric":
			currentElement = electricScript;
			break;
		}
	}
}
