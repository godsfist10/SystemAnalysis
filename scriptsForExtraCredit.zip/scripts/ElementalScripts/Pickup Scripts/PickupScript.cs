﻿using UnityEngine;
using System.Collections;

public abstract class PickupScript : MonoBehaviour {

	public virtual void OnTriggerEnter(Collider collision) 
	{
		if(collision.gameObject.tag == "Player")
		{
			collidedWithPlayer();
		}
	}

	public virtual void collidedWithPlayer()
	{
		Debug.Log ("base pickup script function 'collidedWithPlayer' not overridden");
	}
}
