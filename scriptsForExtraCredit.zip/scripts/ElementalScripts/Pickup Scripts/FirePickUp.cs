﻿using UnityEngine;
using System.Collections;

public class FirePickUp : PickupScript {

	public GameObject manaBar = null;
	public float refillAmount = 0;

	// Use this for initialization

	public override void collidedWithPlayer()
	{
		ManaBar manaDepletion = manaBar.GetComponent<ManaBar>();
		Destroy(gameObject);
		manaDepletion.refundMana(refillAmount);
	}
}
