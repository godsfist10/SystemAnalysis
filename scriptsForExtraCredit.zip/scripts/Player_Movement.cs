﻿using UnityEngine;
using System.Collections;

public class Player_Movement : MonoBehaviour {
	
	public ManaBar manaBarScript = null;

	public float movementSpeed = 0;
	public float rotateSpeed = 0;
	public float jumpSpeed = 0;

	private float distanceToGround;

	// Use this for initialization
	void Start () 
	{
		distanceToGround = collider.bounds.extents.y;
	}
	
	// Update is called once per frame
	void Update () 
	{
		Movement();
		if (IsGrounded()) 
		{	
			Jump();
		}
	}

	void Movement()
	{
		float forwardMovement = Input.GetAxis("Vertical") * movementSpeed;
		float sidewaysMovement = Input.GetAxis("Horizontal") * movementSpeed;
		forwardMovement *= Time.deltaTime;
		sidewaysMovement *= Time.deltaTime;
		transform.Translate(sidewaysMovement, 0, forwardMovement);


	}

	void Jump()
	{
		if(Input.GetButtonDown("Jump"))
		{
			gameObject.rigidbody.AddForce(Vector3.up * jumpSpeed);
		}
	}

	bool IsGrounded()
	{
		bool tempBool = Physics.Raycast(transform.position, - Vector3.up, distanceToGround + 0.1f);
		manaBarScript.isGrounded(tempBool);
		return tempBool;
	}
}
