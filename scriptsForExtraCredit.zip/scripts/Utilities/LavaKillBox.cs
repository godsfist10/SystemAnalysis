﻿using UnityEngine;
using System.Collections;

public class LavaKillBox : KillBox 
{
	public override void OnTriggerEnter (Collider collider)
	{
		if( collider.tag == "Ice")
		{
			Destroy(collider.gameObject);
		}
		else
		{
			base.OnTriggerEnter (collider);
		}
	}
}
