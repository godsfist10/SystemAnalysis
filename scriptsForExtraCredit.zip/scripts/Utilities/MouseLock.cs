﻿using UnityEngine;
using System.Collections;

public class MouseLock : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		Screen.lockCursor = true;
	}
	
	void Update()
	{
		if(!Screen.lockCursor && Input.GetKeyDown ("mouse 0"))
		{
			Screen.lockCursor = true;
		}
	}

}
