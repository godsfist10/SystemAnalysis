﻿#pragma strict

function OnTriggerEnter(collider:Collider)
{
	if( collider.tag == "Player")
	{
		Application.LoadLevel(Application.loadedLevelName);
	}

}
