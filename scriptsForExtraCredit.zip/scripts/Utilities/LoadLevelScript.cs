﻿using UnityEngine;
using System.Collections;

public class LoadLevelScript : MonoBehaviour {

	//Make sure this level is in build settings
	public string LevelToLoad = "";

	void OnTriggerEnter(Collider collider)
	{
		if (collider.tag == "Player")
		{
			Application.LoadLevel (LevelToLoad);
		}
	}

}
