﻿using UnityEngine;
using System.Collections;

public class KillBox : MonoBehaviour {

	public virtual void OnTriggerEnter(Collider collider)
	{
		if( collider.tag == "Player")
		{
			Application.LoadLevel(Application.loadedLevelName);
		}
	}
}
