﻿using UnityEngine;
using System.Collections;

public class MoveForCollisions : MonoBehaviour {
	
	void Update () 
	{
		transform.Translate (0, 0, 0);
	}
}
