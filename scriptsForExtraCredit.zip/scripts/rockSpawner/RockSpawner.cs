﻿using UnityEngine;
using System.Collections;

public class RockSpawner : MonoBehaviour {
	
	public float timeBetweenSpawns = 0;
	private float timeToSpawn;
	public GameObject rockToSpawn = null;
	public bool spawnTimerGo = false;

	// Use this for initialization
	void Start () {
		timeToSpawn = timeBetweenSpawns;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (timeToSpawn <= 0) 
		{
			Instantiate(rockToSpawn, this.gameObject.transform.position, Quaternion.identity);
			timeToSpawn = timeBetweenSpawns;
			spawnTimerGo = false;
		}
		if( spawnTimerGo)
			timeToSpawn -= Time.deltaTime;
	}
}
