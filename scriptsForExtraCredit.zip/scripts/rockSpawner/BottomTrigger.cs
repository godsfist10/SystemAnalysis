﻿using UnityEngine;
using System.Collections;

public class BottomTrigger : MonoBehaviour {

	public GameObject rockSpawner = null;
	public ParticleSystem lavaWave = null;
	public float sinkSpeed = 0;
	private Vector3 sinkingTranslateVector;
	// Use this for initialization
	void Start () {
		sinkingTranslateVector = new Vector3 (0, sinkSpeed, 0);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider collider)
	{
		if (collider.tag == "fallingRock") 
		{
			//Debug.Log("Rock Vel:  " + collider.gameObject.rigidbody.velocity);
			collider.gameObject.rigidbody.useGravity = false;
			lavaWave.enableEmission = true;
			collider.gameObject.rigidbody.velocity = Vector3.zero;
			collider.gameObject.rigidbody.angularVelocity = Vector3.zero;
			//Debug.Log("Rock Vel Post Func:  " + collider.gameObject.rigidbody.velocity);
		}
	}

	void OnTriggerStay(Collider collider)
	{
		collider.gameObject.rigidbody.velocity = sinkingTranslateVector;
		//Debug.Log ("Velocity: " + collider.gameObject.rigidbody.velocity);
	}

	void OnTriggerExit( Collider collider)
	{
		if (collider.tag == "fallingRock") 
		{
			Destroy (collider.gameObject);
			lavaWave.enableEmission = false;
			RockSpawner rockSpawnScript = rockSpawner.GetComponent<RockSpawner>();
			rockSpawnScript.spawnTimerGo = true;
		}
	}
}
