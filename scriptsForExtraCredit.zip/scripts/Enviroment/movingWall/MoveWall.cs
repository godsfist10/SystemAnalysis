﻿using UnityEngine;
using System.Collections;

public class MoveWall : MonoBehaviour {

	public Vector3 movementDirection = Vector3.zero;
	public float distance = 0;
	public float speed = 0;
	public float retractedDelayTime = 0;
	public float extendedDelayTime = 0;
	public float startupOffsetTime = 0;
	public bool frozen {get; set;}
	public bool inhibitSpeed {get; set;}

	
	private float timePassed = 0;
	private float mSpeed = 0;
	private bool extending = true;
	private bool delay = false;
	private Vector3 translationVector = Vector3.zero;
	private float distanceCounter = 0;

	
	// Use this for initialization
	void Start () 
	{ 
		translationVector = speed * movementDirection;
		mSpeed = speed;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (!frozen) 
		{
			if( startupOffsetTime > 0)
			{
				startupOffsetTime -= Time.deltaTime;
			}
			else if( delay)
			{
				timePassed += Time.deltaTime;
				if( timePassed >= (extending ? retractedDelayTime : extendedDelayTime))
				{
					delay = false;
					timePassed = 0.0f;
					distanceCounter = 0;
				}
			}
			else
			{
				if( distanceCounter >= distance)
				{
					extending = !extending;
					delay = true;
					updateSpeed();
				}
				else
				{
					transform.Translate (extending ? translationVector : -translationVector);
					distanceCounter += mSpeed;
				}
			}
		}
		else 
		{
			transform.Translate(0,0,0);
		}
	}

	void updateSpeed()
	{
		if( inhibitSpeed)
		{
			mSpeed = .25f * speed;
		}
		else
		{
			mSpeed = speed;
		}

		translationVector = mSpeed * movementDirection;
	}
	


}
