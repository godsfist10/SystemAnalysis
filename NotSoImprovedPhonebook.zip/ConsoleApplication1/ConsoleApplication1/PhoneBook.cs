﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

struct phoneBookEntry
{
    public string name;
    public string address;
    public string phoneNumber;
}

namespace ConsoleApplication1
{
    class PhoneBook
    {
        private List<phoneBookEntry> mEntryList;

        public PhoneBook()
        {
            mEntryList = new List<phoneBookEntry>();
        }

        //public ~PhoneBook(){}

        public int addEntry(string entryName, string entryAddress, string entryPhoneNumber)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (entryName == mEntryList[i].name)
                {
                    return 1;
                }
                else if ( entryAddress == mEntryList[i].address)
                {
                    return 2;
                }
                else if (entryPhoneNumber == mEntryList[i].phoneNumber)
                {
                    return 3;
                }
            }

            phoneBookEntry tempEntry;
            tempEntry.name = entryName;
            tempEntry.address = entryAddress;
            tempEntry.phoneNumber = entryPhoneNumber;
            mEntryList.Add(tempEntry);

            return 0;
        }

        private bool addEntry( phoneBookEntry newEntry)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (newEntry.name == mEntryList[i].name)
                {
                    return false;
                }
                else if (newEntry.address == mEntryList[i].address)
                {
                    return false;
                }
                else if (newEntry.phoneNumber == mEntryList[i].phoneNumber)
                {
                    return false;
                }
            }

            mEntryList.Add(newEntry);
            return true;
        }

        public bool loadSavedPhoneBook(string filename)
        {
            //string[] phoneBookFileText = System.IO.File.ReadAllLines(filename);

            if (!System.IO.File.Exists(filename))
                return false;

            string line;
            StreamReader file = new StreamReader(filename);
            while ((line = file.ReadLine()) != null)
            {
                if (line == "ADD ENTRY")
                {
                    phoneBookEntry tempNewEntry;
                    tempNewEntry.name = file.ReadLine();
                    tempNewEntry.address = file.ReadLine();
                    tempNewEntry.phoneNumber = file.ReadLine();
                    addEntry(tempNewEntry);
                }
            }
            file.Close();
            return true;
        }

        public bool savePhoneBook(string filename, bool overWrite)
        {
            if (System.IO.File.Exists(filename) && !overWrite)
                return false;

            StreamWriter file = new StreamWriter(filename);

            for (int i = 0; i < mEntryList.Count; i++)
            {
                file.WriteLine("ADD ENTRY");
                file.WriteLine(mEntryList[i].name);
                file.WriteLine(mEntryList[i].address);
                file.WriteLine(mEntryList[i].phoneNumber);
                file.WriteLine("");
            }
            file.Close();

            return true;
        }

        public bool removeEntry(string entryName)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (entryName == mEntryList[i].name)
                {
                    mEntryList.RemoveAt(i);
                    return true;
                }
               
            }
            return false;
        }

        public phoneBookEntry searchName(string nameSearch)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (nameSearch == mEntryList[i].name)
                {
                    return mEntryList[i];
                }
            }
            return returnEmptyEntry();
        }

        public phoneBookEntry searchAddress(string addressSearch)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (addressSearch == mEntryList[i].address)
                {
                    return mEntryList[i];
                }
            }
            return returnEmptyEntry();
        }

        public phoneBookEntry searchPhoneNumber(string phoneNumberSearch)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (phoneNumberSearch == mEntryList[i].phoneNumber)
                {
                    return mEntryList[i];
                }
            }
            return returnEmptyEntry();
        }

        private phoneBookEntry returnEmptyEntry()
        {
            phoneBookEntry empty;
            empty.name = "";
            empty.address = "";
            empty.phoneNumber = "";
            return empty;
        }

    }
}
