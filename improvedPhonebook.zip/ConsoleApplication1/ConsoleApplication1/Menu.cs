﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Menu
    {
        public void printMenu()
        {
            Console.WriteLine("What would you like to do?\n" +
                                  "1:  Add an entry\n" +
                                  "2:  Remove an entry\n" +
                                  "3:  Search for an entry\n" +
                                  "4:  Export phonebook\n" +
                                  "5:  Load saved phonebook\n" +
                                  "6:  Quit\n");
        }


    }
}
