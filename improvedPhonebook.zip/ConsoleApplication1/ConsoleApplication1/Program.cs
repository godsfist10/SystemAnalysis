﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            char menuChoice = 'a';
            PhoneBook mPhoneBook = new PhoneBook();
            Menu mMenu = new Menu();

            while (menuChoice != '6')
            {
                mMenu.printMenu();

                menuChoice = Console.ReadKey().KeyChar;

                if (menuChoice == '1') //add
                {
                    Console.Clear();
                    Console.WriteLine("--------- New Entry ----------\n\nName:  ");
                    string tempName = Console.ReadLine();
                    Console.WriteLine("Address:  ");
                    string tempAddress = Console.ReadLine();
                    Console.WriteLine("Zip Code:  ");
                    string tempZipCode = Console.ReadLine();
                    Console.WriteLine("Phone Number (no spaces or dashes:  ");
                    string tempPhoneNumber = Console.ReadLine();
                    Console.WriteLine("\nIs this correct? (y/n)");
                    bool tempDone = false;

                    while( !tempDone)
                    {
                        char answer = Console.ReadKey().KeyChar;
                        if( answer == 'y')
                        {
                            int tempInt = mPhoneBook.addEntry(tempName, tempAddress, tempPhoneNumber, tempZipCode);
                            if( tempInt == 0)
                            {
                                Console.Clear();
                                Console.WriteLine("New entry added\n\nPress any key to return to main menu");
                            }
                            else if(tempInt == 1)
                            {
                                Console.Clear();
                                Console.WriteLine("Name already in phone book\n\nPress any key to return to main menu");
                            }
                            else if(tempInt == 2)
                            {
                                Console.Clear();
                                Console.WriteLine("Address already in phone book\n\nPress any key to return to main menu");
                            }
                            else if(tempInt == 3)
                            {
                                Console.Clear();
                                Console.WriteLine("Phone number already in phone book\n\nPress any key to return to main menu");
                            }
                            else if (tempInt == 4)
                            {
                                Console.Clear();
                                Console.WriteLine("Zip Code Invalid Length\n\nPress any key to return to main menu");
                            }
                            else if (tempInt == 5)
                            {
                                Console.Clear();
                                Console.WriteLine("Phone Number Invalid Length\n\nPress any key to return to main menu");
                            }
                            
                            tempDone = true;
                        }
                        else if( answer == 'n')
                        {
                            Console.Clear();
                            Console.WriteLine("Press any key to return to main menu");
                            tempDone = true;
                        }
                        else
                        {
                            Console.Clear();
                            Console.Write("--------- New Entry ----------\n\nName:  " + tempName + "\nAddress:  " + tempAddress + ", " + tempZipCode
                                + "\nPhone Number:  " + tempPhoneNumber + "\n\nIs this correct? (y/n): INVALID RESPONSE");

                        }
                    }

                }
                else if (menuChoice == '2') //remove
                {
                    Console.Clear();
                    Console.WriteLine("--------- Remove Entry --------\n\nName to remove:  ");
                    string tempName = Console.ReadLine();

                    if( mPhoneBook.removeEntry(tempName))
                    {
                        Console.Clear();
                        Console.WriteLine("Entry Removed\n\nPress any key to return to main menu");
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Name not present within phonebook\n\nPress any key to return to main menu");
                    }

                }
                else if (menuChoice == '3')  //search
                {
                    Console.Clear();
                    char answer = 'a';

                    while (answer != '4')
                    {
                        Console.Clear();
                        Console.WriteLine("--------- Search For Entry --------\n\nWhat would you like to search for\n1: Name\n2: Address\n3: Phone Number\n4: Return To Menu\n  ");
                        answer = Console.ReadKey().KeyChar;

                        if (answer == '1')
                        {
                            Console.Clear();
                            Console.WriteLine("Enter the name to search for:  ");
                            bool found = mPhoneBook.searchName(Console.ReadLine());

                            if (!found)
                            {
                                Console.Clear();
                                Console.WriteLine("Name not in phonebook\n\nPress any key to continue");
                            }


                        }
                        else if (answer == '2')
                        {
                            Console.Clear();
                            Console.WriteLine("Enter the address to search for:  ");
                            bool found = mPhoneBook.searchAddress(Console.ReadLine());

                            if (!found)
                            {
                                Console.Clear();
                                Console.WriteLine("Address not in phonebook\n\nPress any key to continue");
                            }


                        }
                        else if (answer == '3')
                        {
                            Console.Clear();
                            Console.WriteLine("Enter the phone number to search for:  ");
                            bool found = mPhoneBook.searchPhoneNumber(Console.ReadLine());

                            if (!found)
                            {
                                Console.Clear();
                                Console.WriteLine("Phone number not in phonebook\n\nPress any key to continue");

                            }

                        }
                        else if (answer != '4')
                        {
                            Console.Clear();
                            Console.WriteLine("INVALID ENTRY\n\nPress any key to return");
                        }

                        if( answer != '4')
                            Console.ReadKey();
                        if (answer == '4')
                        {
                            Console.Clear();
                            Console.WriteLine("Press any key to return to main menu");
                        }
                    }
                        
                }
                else if (menuChoice == '4') //save
                {
                    Console.Clear();
                    Console.WriteLine("--------- Save Phonebook --------");
                    Console.WriteLine("\n\nEnter the filename to save to (without file extension):");
                    string tempFilename = Console.ReadLine();
                    Console.WriteLine("Text file or XML file: \n1:txt\n2:xml\n");
                    string txtOrXml = Console.ReadLine();
                    bool xml = txtOrXml == "1" ? false : true;
                    

                    if (mPhoneBook.savePhoneBook(tempFilename, false, xml))
                    {
                        Console.Clear();
                        Console.WriteLine("Phone book saved\n\nPress any key to return to main menu");
                    }
                    else
                    {
                        Console.WriteLine("File already exists. Overwrite it? (y/n)");
                        bool tempDone = false;

                        while (!tempDone)
                        {
                            char answer = Console.ReadKey().KeyChar;
                            if (answer == 'y')
                            {
                                mPhoneBook.savePhoneBook(tempFilename, true, xml);
                                Console.Clear();
                                Console.WriteLine("Phone book saved\n\nPress any key to return to main menu");
                                tempDone = true;
                            }
                            else if (answer == 'n')
                            {
                                Console.Clear();
                                Console.WriteLine("Press any key to return to main menu");
                                tempDone = true;
                            }
                            else
                            {
                                Console.Clear();
                                Console.Write("--------- Save Phonebook --------\n\nEnter the filename to save to:\n" + tempFilename +
                                    "File already exists. Overwrite it? (y/n): INVALID RESPONSE");
                            }

                        }
                    }
                }
                else if (menuChoice == '5') //load
                {
                    Console.Clear();
                    Console.Write("--------- Load Phonebook --------\n\nEnter the filename to load from (without file extension):  ");
                    string fileName = Console.ReadLine();
                    Console.WriteLine("Text file or XML file: \n1:txt\n2:xml\n");
                    string txtOrXml = Console.ReadLine();
                    bool xml = txtOrXml == "1" ? false : true;

                    if (mPhoneBook.loadSavedPhoneBook(fileName, xml))
                    {
                        Console.Clear();
                        Console.WriteLine("Phone book loaded\n\nPress any key to continue");
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("File does not exist\n\nPress any key to return to main menu");
                    }
                    
                
                }
                else if (menuChoice != '6')
                {
                    Console.Clear();
                    Console.WriteLine("Invalid Entry: press any key to go back to the main menu\n");
                }

                if( menuChoice != '6')
                    Console.ReadKey();
                Console.Clear();
            }

        }
    }
}
