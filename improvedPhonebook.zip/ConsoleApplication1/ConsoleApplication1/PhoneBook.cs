﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;


struct phoneBookEntry
{
    public string name;
    public string address;
    public string zipCode;
    public string phoneNumber;
}

namespace ConsoleApplication1
{
    internal class PhoneBook
    {
        private List<phoneBookEntry> mEntryList;

        public PhoneBook()
        {
            mEntryList = new List<phoneBookEntry>();
        }

        //public ~PhoneBook(){}

        public int addEntry(string entryName, string entryAddress, string entryPhoneNumber, string zipCode)
        {
            if (zipCode.Length != 5)
                {
                    return 4;
                }
            else if (entryPhoneNumber.Length != 10)
                {
                    return 5;
                }

            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (entryName == mEntryList[i].name)
                {
                    return 1;
                }
                else if (entryAddress == mEntryList[i].address)
                {
                    return 2;
                }
                else if (entryPhoneNumber == mEntryList[i].phoneNumber)
                {
                    return 3;
                }
                
            }

            phoneBookEntry tempEntry;
            tempEntry.name = entryName;
            tempEntry.address = entryAddress;
            tempEntry.phoneNumber = entryPhoneNumber;
            tempEntry.zipCode = zipCode;
            mEntryList.Add(tempEntry);

            return 0;
        }

        private bool addEntry(phoneBookEntry newEntry)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (newEntry.name == mEntryList[i].name)
                {
                    return false;
                }
                else if (newEntry.address == mEntryList[i].address)
                {
                    return false;
                }
                else if (newEntry.phoneNumber == mEntryList[i].phoneNumber)
                {
                    return false;
                }
            }

            mEntryList.Add(newEntry);
            return true;
        }

        public bool loadSavedPhoneBook(string filename, bool xml)
        {
            //string[] phoneBookFileText = System.IO.File.ReadAllLines(filename);

            filename = xml ? filename + ".xml" : filename + ".txt";

            if (!System.IO.File.Exists(filename))
                return false;

            if (xml)
            {
                loadSavedPhoneBookXml(filename);
            }
            else
            {
                loadSavedPhoneBookTxt(filename);
            }

            return true;
        }

        private void loadSavedPhoneBookTxt(string filename)
        {
            string line;
            StreamReader file = new StreamReader(filename);
            while ((line = file.ReadLine()) != null)
            {
                if (line == "ADD ENTRY")
                {
                    phoneBookEntry tempNewEntry;
                    tempNewEntry.name = file.ReadLine();
                    tempNewEntry.address = file.ReadLine();
                    tempNewEntry.phoneNumber = file.ReadLine();
                    tempNewEntry.zipCode = file.ReadLine();
                    addEntry(tempNewEntry);
                }
            }
            file.Close();
        }

        private void loadSavedPhoneBookXml(string filename)
        {
            using (XmlReader reader = XmlReader.Create(filename))
            {
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        switch (reader.Name)
                        {
                            case "Entry":

                                phoneBookEntry tempNewEntry;

                                tempNewEntry.name = reader["Name"];
                                tempNewEntry.address = reader["Address"];
                                tempNewEntry.zipCode = reader["ZipCode"];
                                tempNewEntry.phoneNumber = reader["PhoneNumber"];

                                addEntry(tempNewEntry);
                                break;
                        }
                    }
                }
            }
        }

        public bool savePhoneBook(string filename, bool overWrite, bool xml)
        {
            filename = xml ? filename + ".xml" : filename + ".txt";

            if (System.IO.File.Exists(filename) && !overWrite)
                return false;

            if (!xml)
            {
                savePhoneBookTxt(filename);
            }
            else
            {
                savePhoneBookXml(filename);
            }
            return true;
        }

        private void savePhoneBookTxt(string filename)
        {
            StreamWriter file = new StreamWriter(filename);

            for (int i = 0; i < mEntryList.Count; i++)
            {
                file.WriteLine("ADD ENTRY");
                file.WriteLine(mEntryList[i].name);
                file.WriteLine(mEntryList[i].address);
                file.WriteLine(mEntryList[i].phoneNumber);
                file.WriteLine(mEntryList[i].zipCode);
                file.WriteLine("");
            }
            file.Close();
        }

        private void savePhoneBookXml(string filename)
        {
            using (XmlWriter writer = XmlWriter.Create(filename))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("PhoneBook");

                foreach (phoneBookEntry entry in mEntryList)
                {
                    writer.WriteStartElement("Entry");
                 
                    writer.WriteAttributeString("Name", entry.name);
                    writer.WriteAttributeString("Address", entry.address);
                    writer.WriteAttributeString("ZipCode", entry.zipCode);
                    writer.WriteAttributeString("PhoneNumber", entry.phoneNumber);

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndDocument();

            }
        }


        public
            bool removeEntry(string entryName)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (entryName == mEntryList[i].name)
                {
                    mEntryList.RemoveAt(i);
                    return true;
                }
               
            }
            return false;
        }

        private void printPhonebookEntry(int entryNum)
        {
            Console.Clear();
            Console.Write("Name:  " + mEntryList[entryNum].name + "\nAddress:  " + mEntryList[entryNum].address + ", " + mEntryList[entryNum].zipCode + "\nPhone Number:  " + mEntryList[entryNum].phoneNumber + "\n\nPress any key to continue");
        }

        public bool searchName(string nameSearch)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (nameSearch == mEntryList[i].name)
                {
                    printPhonebookEntry(i);
                    return true;
                }
            }
            return false;
            
        }

        public bool searchAddress(string addressSearch)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (addressSearch == mEntryList[i].address)
                {
                    printPhonebookEntry(i);
                    return true;
                }
            }
            return false;
            
        }

        public bool searchPhoneNumber(string phoneNumberSearch)
        {
            for (int i = 0; i < mEntryList.Count; i++)
            {
                if (phoneNumberSearch == mEntryList[i].phoneNumber)
                {
                    printPhonebookEntry(i);
                    return true;
                }
            }
            return false;
        }

        private phoneBookEntry returnEmptyEntry()
        {
            phoneBookEntry empty;
            empty.name = "";
            empty.address = "";
            empty.phoneNumber = "";
            empty.zipCode = "";
            return empty;
        }

    }
}
